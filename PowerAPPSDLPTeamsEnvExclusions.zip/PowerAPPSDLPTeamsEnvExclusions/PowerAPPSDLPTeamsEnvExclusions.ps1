<#	
    .NOTES
    ===========================================================================
    Created with: 	ISE
    Created on:   	10/20/2021 1:46 PM
    Created by:   	Vikas Sukhija
    Organization: 	
    Filename:     	PowerAPPSDLPTeamsEnvExclusions.ps1
    ===========================================================================
    .DESCRIPTION
    This Script will exlusde the teams enviornment and others envs
#>
#####################Load variables and log############################
$log = Write-Log -Name "PowerAPPSDLPTeamsEnvExclusions" -folder "logs" -Ext "log"
$defaultdlpEnvs = Write-Log -Name "defaultdlpEnvs" -folder "logs" -Ext "txt"
$teamsdlpEnvs = Write-Log -Name "TeamsdlpEnvs" -folder "logs" -Ext "txt"
	
$countofchanges = "10"
$logrecyclelimit = "60"
$configfile = "E:\scheduledscripts\identity\Config.ini"
$defaultDLPPolicy ="ee23a0a9-6061-4562-9e09-b38b096b7b11"
$defaultDLPPolicyDisplayanme = "Office365 (default)"
$teamspolicyid = "696cae96-478a-4348-a2b6-fb09ab047f5e"
$teamspolicydisplayname = "Teams Only + CDS"

. .\PowerappsMSFunctions.ps1 #load functions for powerapps dlp
################get Graoph###############################
 Write-Log -Message "Start ................Script" -path $log
 Write-Log -Message "Get Crendetials for Admin ID" -path $log
if(Test-Path -Path ".\Password.xml"){
  Write-Log -Message "Password file Exists" -path $log
}else{
  Write-Log -Message "Generate password" -path $log
  $Credential = Get-Credential 
  $Credential | Export-Clixml ".\Password.xml"
}
#########################################################
$Credential = $null
$Credential = Import-Clixml ".\Password.xml"
#########################################################
  try
  {
    Add-PowerAppsAccount -Username $Credential.UserName -Password $Credential.Password
    Write-Log -Message "Connect PowerAPPs" -path $log
  }
  catch
  {
    $exception = $_.Exception.Message
    Write-Log -Message "exception $exception has occured" -path $log -Severity Error
  }

try{
   $getdefaultDlpPol = Get-AdminDlpPolicy -PolicyName $defaultDLPPolicy
   $getdefaultDlpPolEnvs = $getdefaultDlpPol.Environments | Select @{n="Environments";e={$_.ID.split("/")[-1]}}
   $defaultexcludedEnvs = $getdefaultDlpPolEnvs | Select -ExpandProperty Environments 
   Write-Log -Message "collected all excluded environments from policy $defaultDLPPolicyDisplayanme" -path $log
   $getteamsDlpPol = Get-AdminDlpPolicy -PolicyName $teamspolicyid
   $getteamsDlpPolEnvs = $getteamsDlpPol.Environments | Select @{n="Environments";e={$_.ID.split("/")[-1]}}
   $teamsenvs = $getteamsDlpPolEnvs | Select -ExpandProperty Environments
   Write-Log -Message "collected all Teams Env from TEams Policy $teamspolicydisplayname" -path $log
   $compare = Compare-Object -ReferenceObject $defaultexcludedEnvs -DifferenceObject $teamsenvs
   if($compare){
     $getdefallenvs = $compare | where{$_.SideIndicator -eq "<="} | select -ExpandProperty InputObject 
      if($getdefallenvs.count -gt $countofchanges){
        $getdefallenvs | Out-File $defaultdlpEnvs #export to file for refrence - default exclusions
        $teamsenvs  | Out-File $teamsdlpEnvs #export to file for refrence - teams only envs from dlp
        UpdatePolicyEnvironmentsForTeams -OnlyEnvironmentsPolicyName $teamspolicyid -OnlyEnvironmentsPolicyDisplayName $teamspolicydisplayname -ExceptEnvironmentsPolicyName $defaultDLPPolicy -ExceptEnvironmentsPolicyDisplayName $defaultDLPPolicyDisplayanme -ExceptionEnvironmentIds $getdefallenvs
        Write-Log -message  "Default DLP Policy Refreshed" -path $log
      }
      else{
        Write-Log -message  "Number of Changes $($getdefallenvs.count) is less than $countofchanges" -path $log -Severity Warning
      }
   }
   if($error){
     Write-Log -Message "error $error has occured" -path $log -Severity Error
   }
   else{
    Write-Log -Message "Updated the DLP default Policy - $defaultDLPPolicyDisplayanme" -path $log
   }
}
catch{
    $exception = $_.Exception.Message
    Write-Log -Message "exception $exception has occured" -path $log -Severity Error
}
Remove-PowerAppsAccount
Write-Log -Message "Remove PowerAPPs" -path $log
##############################Recycle Logs##########################
Write-Log -Message "Recycle Logs" -path $log -Severity Information

Set-Recyclelogs -foldername "logs" -limit $logrecyclelimit -Confirm:$false
Set-Recyclelogs -foldername "Report" -limit $logrecyclelimit -Confirm:$false
Write-Log -Message "Script Finished" -path $log -Severity Information

################################################################################