######################################################################
######################################################################
#               Author: Vikas Sukhija
#               Date:- 11/05/2014
#		Modified:- 07/23/2015 (updated to use WINSCP)
#               Description:- This will download the FileV3 csv
#               file & monitor it daily
######################################################################
######Download file from sftp##########################################

$date = get-date -format d
$date = $date.ToString().Replace(�/�, �-�)
$time = get-date -format t
$time = $time.ToString().Replace(":", "-")
$time = $time.ToString().Replace(" ", "")

$logs = ".\Logs" + "\" + "Powershell" + $date + "_" + $time + "_.txt"

$smtpServer = "smtp.labtest.com"
$fromadd = "DoNotReply@labtest.com"
$email1 = "Sukhija@labtest.com"


$date1=get-date -format d

Start-Transcript -Path $logs 

####Enter the Secure FTP details ###################################################

.\winscp556\WinSCP.com /script=command2.txt

$lwrt=Get-ChildItem .\FileV3.csv

if($lwrt.LastWriteTime -like "$date1*")
{
Write-host "File for Today found on SFTP Site" -ForegroundColor green
Move-Item .\FileV3.csv .\FileV3Files\FileV3-$date.csv
}
else
{
write-host "FileV3-check file no uploaded Today, Pls Check" -ForegroundColor yellow
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "FileV3-check file not uploaded Today, Pls Check"
$msg.Body = "FileV3-check file not uploaded Today, Pls Check"
$smtp.Send($msg)

}

########################################################################
if ($error -ne $null)
      {
#SMTP Relay address
$msg = new-object Net.Mail.MailMessage
$smtp = new-object Net.Mail.SmtpClient($smtpServer)
#Mail sender
$msg.From = $fromadd
#mail recipient
$msg.To.Add($email1)
$msg.Subject = "FileV3 Monitoring script error"
$msg.Body = $error
$smtp.Send($msg)
       }

Stop-Transcript
#############################################################################